
/**
 * BizBook Brain — Central Entry Point
 *
 * All website pages should import BizBook Brain functionality
 * from this file rather than accessing business storage directly.
 *
 * This file only re-exports functionality.
 * Financial operations belong in services and engines.
 */

// Core types, constants and errors
export * from "./types";
export * from "./constants";
export * from "./errors";

// Money utilities
export * from "./money";

// Validation engine
// Allocation validation is exported from installment-engine
// to avoid duplicate exports.
export {
  validateAmount,
  validateStudent,
  validateInstallment,
  validatePaymentMethod,
  validateDate,
  validatePayrollMonth,
  validateStaff,
  validateAttendanceStatus,
  validateAttendanceInput,
  validateAttendanceRecord,
  validateSalaryCalculationMode,
  validateSalaryCalculationInput,
  validateSalaryPaymentInput,
  validateExpenseInput,
  validateExpenseRecord,
} from "./validation-engine";

// Storage adapter
export * from "./storage-adapter";

// Installment engine
export {
  getInstallmentRemaining,
  getTotalInstallmentRemaining,
  validateInstallmentAllocation,
  applyInstallmentPayment,
  applyInstallmentAdvance,
} from "./installment-engine";

// Payment and advance engines/services
export * from "./payment-engine";
export * from "./advance-engine";
export * from "./advance-service";

// Balances and accounting
export * from "./balance-engine";
export * from "./accounting-engine";

// Refunds, reconciliation and audit
export * from "./refund-engine";
export * from "./reconciliation-engine";
export * from "./audit-engine";

// Reports, receipts and invoices
export * from "./report-engine";
export * from "./receipt-engine";
export * from "./invoice-engine";

// Reminders and notifications
export * from "./reminder-engine";
export * from "./reminder-templates";
export * from "./reminder-log";
export * from "./notification-service";

// Payment provider abstraction
export * from "./payment-provider";
export * from "./attendance-service";

export * from "./salary-engine";
export * from "./salary-service";
export * from "./expense-engine";
export * from "./expense-service";

/**
 * BizBook Brain — Money Utilities
 *
 * Handles monetary calculations consistently.
 * This file does not save payments or change student records.
 */

import { BizBookError } from "./errors";

/**
 * Convert rupees into integer paise.
 * Example: ₹150.50 -> 15050 paise
 */
export function toPaise(amount: number): number {
  if (!Number.isFinite(amount) || amount < 0) {
    throw new BizBookError(
      "INVALID_AMOUNT",
      "Amount must be a valid non-negative number.",
      { amount }
    );
  }

  const paise = Math.round((amount + Number.EPSILON) * 100);

  if (!Number.isSafeInteger(paise)) {
    throw new BizBookError(
      "INVALID_AMOUNT",
      "Amount is too large to calculate safely.",
      { amount }
    );
  }

  return paise;
}

/**
 * Convert integer paise into rupees.
 * Example: 15050 paise -> ₹150.50
 */
export function fromPaise(paise: number): number {
  if (!Number.isSafeInteger(paise) || paise < 0) {
    throw new BizBookError(
      "INVALID_AMOUNT",
      "Paise must be a non-negative safe integer.",
      { paise }
    );
  }

  return paise / 100;
}

/**
 * Add multiple amounts safely.
 */
export function addMoney(...amounts: number[]): number {
  const totalPaise = amounts.reduce((total, amount) => {
    const nextTotal = total + toPaise(amount);

    if (!Number.isSafeInteger(nextTotal)) {
      throw new BizBookError(
        "INVALID_AMOUNT",
        "Total amount is too large to calculate safely."
      );
    }

    return nextTotal;
  }, 0);

  return fromPaise(totalPaise);
}

/**
 * Subtract one amount from another.
 * Rejects deductions greater than the available amount.
 */
export function subtractMoney(
  amount: number,
  deduction: number
): number {
  const remainingPaise = toPaise(amount) - toPaise(deduction);

  if (remainingPaise < 0) {
    throw new BizBookError(
      "INSUFFICIENT_BALANCE",
      "Deduction cannot exceed the available amount.",
      { amount, deduction }
    );
  }

  return fromPaise(remainingPaise);
}

/**
 * Calculate outstanding fees.
 *
 * Extra payments are not silently discarded.
 * Handle any excess separately as advance.
 */
export function calculateOutstanding(
  totalFee: number,
  totalReceived: number
): number {
  const feePaise = toPaise(totalFee);
  const receivedPaise = toPaise(totalReceived);

  if (receivedPaise > feePaise) {
    throw new BizBookError(
      "INSUFFICIENT_BALANCE",
      "Received amount exceeds the total fee. Handle the extra amount as advance separately.",
      { totalFee, totalReceived }
    );
  }

  return fromPaise(feePaise - receivedPaise);
}

/**
 * Format an amount using Indian currency notation.
 * Example: ₹1,25,000.00
 */
export function formatINR(amount: number): string {
  toPaise(amount);

  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

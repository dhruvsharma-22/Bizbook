
/**
 * BizBook Brain — Payment Provider
 *
 * Responsibilities:
 * - Define a common interface for payment providers.
 * - Validate payment-order and verification inputs.
 * - Provide a development-only mock provider.
 *
 * Security rules:
 * - Mock orders are never real payment confirmations.
 * - Mock verification always returns verified: false.
 * - Real provider signatures and webhooks must be verified
 *   on a trusted server, never in browser-only code.
 */

import { BizBookError } from "./errors";
import { toPaise, fromPaise } from "./money";

export interface CreateProviderOrderInput {
  paymentId: string;
  amount: number;
  currency?: "INR";
  studentId: string;
  coachingId: string;
}

export interface ProviderOrder {
  provider: string;
  orderId: string;
  paymentId: string;
  amount: number;
  currency: "INR";
  status: "SIMULATED";
  checkoutUrl?: string;
  createdAt: string;
}

export interface ProviderVerificationInput {
  orderId: string;
  paymentId: string;
  providerPaymentId: string;
  amount: number;
  signature?: string;
}

export interface ProviderVerificationResult {
  verified: boolean;
  provider: string;
  orderId: string;
  paymentId: string;
  providerPaymentId: string;
  amount: number;
  verifiedAt?: string;
  message: string;
}

export interface PaymentProvider {
  readonly name: string;

  createOrder(
    input: CreateProviderOrderInput
  ): Promise<ProviderOrder>;

  verifyPayment(
    input: ProviderVerificationInput
  ): Promise<ProviderVerificationResult>;
}

/* =========================================================
   VALIDATION
========================================================= */

function requireText(
  value: unknown,
  field: string
): asserts value is string {
  if (
    typeof value !== "string" ||
    value.trim().length === 0
  ) {
    throw new BizBookError(
      "VALIDATION_ERROR",
      `${field} is required.`,
      { field }
    );
  }
}

function validatePositiveAmount(amount: unknown): number {
  if (
    typeof amount !== "number" ||
    !Number.isFinite(amount) ||
    amount <= 0
  ) {
    throw new BizBookError(
      "INVALID_AMOUNT",
      "Payment amount must be greater than zero."
    );
  }

  // Convert through the shared money utility so invalid
  // precision and unsafe currency values are rejected.
  return fromPaise(toPaise(amount));
}

function validateOrderInput(
  input: CreateProviderOrderInput
): void {
  if (!input || typeof input !== "object") {
    throw new BizBookError(
      "VALIDATION_ERROR",
      "Payment order details are required."
    );
  }

  requireText(input.paymentId, "Payment ID");
  requireText(input.studentId, "Student ID");
  requireText(input.coachingId, "Coaching ID");

  validatePositiveAmount(input.amount);

  if (
    input.currency !== undefined &&
    input.currency !== "INR"
  ) {
    throw new BizBookError(
      "VALIDATION_ERROR",
      "Only INR currency is supported."
    );
  }
}

function validateVerificationInput(
  input: ProviderVerificationInput
): void {
  if (!input || typeof input !== "object") {
    throw new BizBookError(
      "VALIDATION_ERROR",
      "Payment verification details are required."
    );
  }

  requireText(input.orderId, "Provider order ID");
  requireText(input.paymentId, "Payment ID");
  requireText(
    input.providerPaymentId,
    "Provider payment ID"
  );

  validatePositiveAmount(input.amount);

  if (
    input.signature !== undefined &&
    typeof input.signature !== "string"
  ) {
    throw new BizBookError(
      "VALIDATION_ERROR",
      "Payment signature must be a string."
    );
  }
}

/* =========================================================
   DEVELOPMENT MOCK PROVIDER
========================================================= */

/**
 * Development-only provider.
 *
 * This provider:
 * - Creates simulated orders only.
 * - Never verifies real payments.
 * - Must never be treated as proof that money was received.
 */
export class MockPaymentProvider implements PaymentProvider {
  readonly name = "Mock";

  async createOrder(
    input: CreateProviderOrderInput
  ): Promise<ProviderOrder> {
    validateOrderInput(input);

    const amount = validatePositiveAmount(input.amount);

    return {
      provider: this.name,
      orderId: `mock_order_${input.paymentId.trim()}`,
      paymentId: input.paymentId.trim(),
      amount,
      currency: input.currency ?? "INR",
      status: "SIMULATED",
      createdAt: new Date().toISOString(),
    };
  }

  async verifyPayment(
    input: ProviderVerificationInput
  ): Promise<ProviderVerificationResult> {
    validateVerificationInput(input);

    // Intentionally never return verified: true.
    return {
      verified: false,
      provider: this.name,
      orderId: input.orderId.trim(),
      paymentId: input.paymentId.trim(),
      providerPaymentId: input.providerPaymentId.trim(),
      amount: validatePositiveAmount(input.amount),
      message:
        "Mock provider cannot verify real payments. Use a trusted server-side provider integration.",
    };
  }
}

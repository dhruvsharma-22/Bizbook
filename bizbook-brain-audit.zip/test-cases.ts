
/**
 * BizBook Brain — Complete Test Suite
 *
 * Covers:
 * - Money calculations
 * - Installments and partial payments
 * - Advance receipts and allocations
 * - Refund calculations
 * - Reminder scheduling
 * - Salary calculations and validation
 * - Attendance services
 * - Salary payment services
 * - Accounting summaries
 * - Duplicate transaction IDs
 * - Accounting category validation
 * - Payment engine validation and verification
 * - Receipt generation and eligibility
 * - Payment-service integration and fee-receipt storage
 *
 * Run:
 * npx tsc --noEmit
 * npx tsx lib/bizbook-brain/test-cases.ts
 */

import { calculateOutstanding, toPaise } from "./money";

import {
  getInstallmentRemaining,
  applyInstallmentPayment,
  applyInstallmentAdvance,
} from "./installment-engine";

import {
  getReceiptAvailableAdvance,
  applyAllocationToReceipt,
} from "./advance-engine";

import { getRefundableAmount } from "./refund-engine";

import {
  createPayment,
  recordOfflinePayment,
  verifyOnlinePayment,
  canApplyPayment,
  getPaymentAmountPaise,
} from "./payment-engine";

import { createPaymentReceipt } from "./receipt-engine";

import {
  createOnlinePayment,
  recordOfflinePaymentService,
  verifyOnlinePaymentService,
  getPaymentReceipt,
} from "./payment-service";

import {
  BIZBOOK_STORAGE_KEYS,
  readAdvancePayments,
  readFeeReceipts,
  readPaymentHistory,
  readPaymentRecords,
} from "./storage-adapter";

import type { RefundRecord } from "./refund-engine";

import {
  getScheduledReminder,
  REMINDER_PLAN,
} from "./reminder-engine";

import { calculateSalary } from "./salary-engine";

import {
  calculateAccountingSummary,
  calculateMixedAccountingSummary,
} from "./accounting-engine";

import type { AccountingEntry } from "./accounting-engine";

import type {
  AdvancePayment,
  AttendanceData,
  PaymentRecord,
  SalaryCalculationInput,
  StaffMember,
  Student,
  StudentsStaffData,
} from "./types";

import {
  ATTENDANCE_STORAGE_KEY,
  SALARY_PAYMENTS_STORAGE_KEY,
  STUDENTS_STAFF_STORAGE_KEY,
} from "./constants";

import {
  markAttendance,
  updateAttendance,
  getAttendanceSummary,
} from "./attendance-service";

import {
  calculateStaffSalary,
  recordSalaryPayment,
  listSalaryPayments,
} from "./salary-service";

/* =========================================================
   MOCK STORAGE
========================================================= */

class MockStorage {
  private data = new Map<string, string>();

  getItem(key: string): string | null {
    return this.data.get(key) ?? null;
  }

  setItem(key: string, value: string): void {
    this.data.set(key, String(value));
  }

  removeItem(key: string): void {
    this.data.delete(key);
  }

  clear(): void {
    this.data.clear();
  }
}

const mockStorage = new MockStorage();

function enableServiceTestStorage(): void {
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: {
      localStorage: mockStorage,
      dispatchEvent: () => true,
    },
  });
}

function resetServiceTestStorage(): void {
  mockStorage.clear();

  const staff: StaffMember = {
    id: "staff-test-1",
    name: "Test Staff",
    designation: "Teacher",
    monthlySalary: 30000,
    joiningDate: "2026-10-01",
    perDayLeaveCut: 1000,
    salaryCalculationMode: "AttendanceBased",
  };

  const data: StudentsStaffData = {
    students: [],
    staff: [staff],
  };

  mockStorage.setItem(
    STUDENTS_STAFF_STORAGE_KEY,
    JSON.stringify(data),
  );

  mockStorage.setItem(
    ATTENDANCE_STORAGE_KEY,
    JSON.stringify({}),
  );

  mockStorage.setItem(
    SALARY_PAYMENTS_STORAGE_KEY,
    JSON.stringify({}),
  );
}

function resetPaymentServiceTestStorage(
  student: Student = {
    id: "payment-service-student",
    name: "Payment Service Student",
    course: "Test Course",
    totalFee: 10000,
    installments: [],
  },
): void {
  enableServiceTestStorage();
  resetServiceTestStorage();

  const existing = JSON.parse(
    mockStorage.getItem(STUDENTS_STAFF_STORAGE_KEY) ??
      JSON.stringify({ students: [], staff: [] }),
  ) as StudentsStaffData;

  mockStorage.setItem(
    STUDENTS_STAFF_STORAGE_KEY,
    JSON.stringify({
      ...existing,
      students: [student],
    }),
  );

  mockStorage.setItem(
    BIZBOOK_STORAGE_KEYS.advancePayments,
    JSON.stringify([]),
  );

  mockStorage.setItem(
    BIZBOOK_STORAGE_KEYS.feeReceipts,
    JSON.stringify([]),
  );

  mockStorage.setItem(
    BIZBOOK_STORAGE_KEYS.paymentHistory,
    JSON.stringify([]),
  );

  mockStorage.setItem(
    BIZBOOK_STORAGE_KEYS.paymentRecords,
    JSON.stringify([]),
  );
}

/* =========================================================
   TEST RUNNER
========================================================= */

export interface TestCaseResult {
  name: string;
  passed: boolean;
  error?: string;
}

export function runBizBookTestCases(): TestCaseResult[] {
  const results: TestCaseResult[] = [];

  function test(
    name: string,
    callback: () => boolean,
  ): void {
    try {
      const passed = callback();

      results.push({
        name,
        passed,
        ...(passed
          ? {}
          : { error: "Expected result did not match." }),
      });
    } catch (error) {
      results.push({
        name,
        passed: false,
        error:
          error instanceof Error
            ? error.message
            : String(error),
      });
    }
  }

  /* =======================================================
     MONEY TESTS
  ======================================================= */

  test("Rupees to paise", () => {
    return toPaise(12.34) === 1234;
  });

  test("Outstanding fee", () => {
    return calculateOutstanding(15000, 5000) === 10000;
  });

  /* =======================================================
     INSTALLMENT TESTS
  ======================================================= */

  test("Legacy installment remaining", () => {
    return (
      getInstallmentRemaining({
        id: "legacy-test",
        amount: 5000,
        status: "Pending",
      }) === 5000
    );
  });

  test("Repeated partial payments", () => {
    const original = {
      id: "legacy-partial",
      amount: 5000,
      status: "Pending" as const,
    };

    const first = applyInstallmentPayment(original, 2000);
    const second = applyInstallmentPayment(first, 1000);

    return (
      getInstallmentRemaining(first) === 3000 &&
      getInstallmentRemaining(second) === 2000
    );
  });

  test("Advance allocation is tracked separately", () => {
    const original = {
      id: "tracked-advance",
      amount: 5000,
      scheduledAmount: 5000,
      paidAmount: 1000,
      advanceAppliedAmount: 0,
      status: "Pending" as const,
    };

    const updated = applyInstallmentAdvance(original, 1500);

    return (
      getInstallmentRemaining(updated) === 2500 &&
      updated.paidAmount === 1000 &&
      updated.advanceAppliedAmount === 1500
    );
  });

  test("Partial payment preserves overdue status", () => {
    const original = {
      id: "legacy-overdue",
      amount: 5000,
      status: "Overdue" as const,
    };

    const updated = applyInstallmentPayment(original, 1000);

    return (
      getInstallmentRemaining(updated) === 4000 &&
      updated.status === "Overdue"
    );
  });

  test("Legacy advance allocation reduces outstanding balance", () => {
    const original = {
      id: "legacy-advance",
      amount: 5000,
      status: "Pending" as const,
    };

    const updated = applyInstallmentAdvance(original, 2000);

    return (
      getInstallmentRemaining(updated) === 3000 &&
      updated.advanceAppliedAmount === 2000 &&
      updated.paidAmount === 0 &&
      updated.scheduledAmount === 5000
    );
  });

  test("Advance allocation greater than outstanding is rejected", () => {
    try {
      applyInstallmentAdvance(
        {
          id: "legacy-overallocation",
          amount: 5000,
          status: "Pending" as const,
        },
        6000,
      );

      return false;
    } catch {
      return true;
    }
  });

  /* =======================================================
     ADVANCE RECEIPT TESTS
  ======================================================= */

  function createTestReceipt(
    overrides: Partial<AdvancePayment> = {},
  ): AdvancePayment {
    return {
      id: "advance-test-1",
      studentId: "student-1",
      studentName: "Test Student",
      course: "Test Course",
      amount: 5000,
      paymentDate: "2026-10-12",
      method: "UPI",
      createdAt: "2026-10-12T10:00:00.000Z",
      appliedAmount: 0,
      appliedTo: [],
      ...overrides,
    };
  }

  test("Full advance amount is available initially", () => {
    return getReceiptAvailableAdvance(createTestReceipt()) === 5000;
  });

  test("Available advance decreases after allocation", () => {
    const updated = applyAllocationToReceipt(
      createTestReceipt(),
      {
        installmentIndex: 0,
        amount: 2000,
        appliedAt: "2026-10-12T10:00:00.000Z",
      },
    );

    return (
      getReceiptAvailableAdvance(updated) === 3000 &&
      updated.appliedAmount === 2000 &&
      updated.appliedTo?.length === 1 &&
      updated.appliedTo[0]?.amount === 2000
    );
  });

  test("Allocation exceeding available advance is rejected", () => {
    try {
      applyAllocationToReceipt(
        createTestReceipt({ appliedAmount: 2000 }),
        {
          installmentIndex: 0,
          amount: 4000,
          appliedAt: "2026-10-12T10:00:00.000Z",
        },
      );

      return false;
    } catch {
      return true;
    }
  });

  test("Advance receipt remains unchanged after allocation", () => {
    const receipt = createTestReceipt();

    applyAllocationToReceipt(receipt, {
      installmentIndex: 0,
      amount: 2000,
      appliedAt: "2026-10-12T10:00:00.000Z",
    });

    return (
      receipt.appliedAmount === 0 &&
      receipt.appliedTo?.length === 0
    );
  });

  test("Available advance cannot be negative", () => {
    try {
      getReceiptAvailableAdvance(
        createTestReceipt({
          amount: 5000,
          appliedAmount: 6000,
        }),
      );

      return false;
    } catch {
      return true;
    }
  });

  /* =======================================================
     REFUND TESTS
  ======================================================= */

  test("Refundable amount", () => {
    const payment = {
      id: "payment-test",
      studentId: "student-test",
      amount: 5000,
      method: "UPI",
      mode: "Manual",
      status: "Paid",
      createdAt: "2026-10-12T10:00:00.000Z",
      updatedAt: "2026-10-12T10:00:00.000Z",
    } as PaymentRecord;

    const refunds: RefundRecord[] = [];

    return getRefundableAmount(payment, refunds) === 5000;
  });

  /* =======================================================
     REMINDER TESTS
  ======================================================= */

  test("Five reminders configured", () => {
    return REMINDER_PLAN.length === 5;
  });

  test("First reminder is email", () => {
    return (
      getScheduledReminder("2026-10-15", "2026-10-12")
        ?.channel === "Email"
    );
  });

  test("Third reminder is WhatsApp", () => {
    return (
      getScheduledReminder("2026-10-15", "2026-10-14")
        ?.channel === "WhatsApp"
    );
  });

  test("No reminder after final scheduled day", () => {
    return (
      getScheduledReminder("2026-10-15", "2026-10-17") === null
    );
  });

  /* =======================================================
     SALARY ENGINE TESTS
  ======================================================= */

  function createSalaryInput(
    overrides: Partial<SalaryCalculationInput> = {},
  ): SalaryCalculationInput {
    return {
      staffId: "staff-test-1",
      month: "2026-10",
      monthlySalary: 30000,
      mode: "AttendanceBased",
      perDayLeaveCut: 500,
      attendance: {},
      joiningDate: "2026-01-01",
      manualAdjustment: 0,
      ...overrides,
    };
  }

  test("Fixed salary has no attendance deductions", () => {
    const attendance: AttendanceData = {
      "staff-test-1__2026-10-05": "Absent",
      "staff-test-1__2026-10-10": "Leave",
    };

    const result = calculateSalary(
      createSalaryInput({ mode: "Fixed", attendance }),
    );

    return (
      result.payableSalary === 30000 &&
      result.deductionDays === 0 &&
      result.attendanceDeduction === 0
    );
  });

  test("Attendance-based salary deducts absent days", () => {
    const attendance: AttendanceData = {
      "staff-test-1__2026-10-05": "Absent",
      "staff-test-1__2026-10-10": "Absent",
    };

    const result = calculateSalary(createSalaryInput({ attendance }));

    return (
      result.deductionDays === 2 &&
      result.attendanceDeduction === 1000 &&
      result.payableSalary === 29000
    );
  });

  test("Attendance-based salary deducts Leave days", () => {
    const attendance: AttendanceData = {
      "staff-test-1__2026-10-05": "Leave",
    };

    const result = calculateSalary(createSalaryInput({ attendance }));

    return (
      result.deductionDays === 1 &&
      result.attendanceDeduction === 500 &&
      result.payableSalary === 29500
    );
  });

  test("Present and Holiday do not cause deductions", () => {
    const attendance: AttendanceData = {
      "staff-test-1__2026-10-05": "Present",
      "staff-test-1__2026-10-06": "Holiday",
    };

    const result = calculateSalary(createSalaryInput({ attendance }));

    return (
      result.deductionDays === 0 &&
      result.attendanceDeduction === 0 &&
      result.payableSalary === 30000
    );
  });

  test("Joining date excludes earlier absence records", () => {
    const attendance: AttendanceData = {
      "staff-test-1__2026-10-10": "Absent",
      "staff-test-1__2026-10-15": "Absent",
      "staff-test-1__2026-10-16": "Absent",
    };

    const result = calculateSalary(
      createSalaryInput({
        joiningDate: "2026-10-15",
        attendance,
      }),
    );

    return (
      result.deductionDays === 2 &&
      result.attendanceDeduction === 1000 &&
      result.payableSalary === 29000
    );
  });

  test("Positive manual adjustment increases salary", () => {
    const result = calculateSalary(
      createSalaryInput({ manualAdjustment: 1000 }),
    );

    return (
      result.manualAdjustment === 1000 &&
      result.payableSalary === 31000
    );
  });

  test("Negative manual adjustment reduces salary", () => {
    const result = calculateSalary(
      createSalaryInput({ manualAdjustment: -1000 }),
    );

    return (
      result.manualAdjustment === -1000 &&
      result.payableSalary === 29000
    );
  });

  test("Payable salary cannot be negative", () => {
    const attendance: AttendanceData = {};

    for (let day = 1; day <= 31; day++) {
      const date = `2026-10-${String(day).padStart(2, "0")}`;
      attendance[`staff-test-1__${date}`] = "Absent";
    }

    const result = calculateSalary(
      createSalaryInput({
        monthlySalary: 1000,
        perDayLeaveCut: 500,
        attendance,
        manualAdjustment: -1000,
      }),
    );

    return result.payableSalary === 0;
  });

  test("Invalid payroll month is rejected", () => {
    try {
      calculateSalary(createSalaryInput({ month: "2026-13" }));
      return false;
    } catch {
      return true;
    }
  });

  test("Invalid attendance status is rejected", () => {
    const attendance = {
      "staff-test-1__2026-10-05": "Unknown",
    } as unknown as AttendanceData;

    try {
      calculateSalary(createSalaryInput({ attendance }));
      return false;
    } catch {
      return true;
    }
  });

  /* =======================================================
     ATTENDANCE SERVICE TESTS
  ======================================================= */

  test("Attendance service saves a record", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    markAttendance({
      staffId: "staff-test-1",
      date: "2026-10-05",
      status: "Present",
    });

    const saved = JSON.parse(
      mockStorage.getItem(ATTENDANCE_STORAGE_KEY) ?? "{}",
    );

    return saved["staff-test-1__2026-10-05"] === "Present";
  });

  test("Attendance service rejects duplicate records", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    const input = {
      staffId: "staff-test-1",
      date: "2026-10-05",
      status: "Present" as const,
    };

    markAttendance(input);

    try {
      markAttendance(input);
      return false;
    } catch {
      return true;
    }
  });

  test("Attendance service updates existing records", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    markAttendance({
      staffId: "staff-test-1",
      date: "2026-10-05",
      status: "Present",
    });

    updateAttendance({
      staffId: "staff-test-1",
      date: "2026-10-05",
      status: "Absent",
    });

    const saved = JSON.parse(
      mockStorage.getItem(ATTENDANCE_STORAGE_KEY) ?? "{}",
    );

    return saved["staff-test-1__2026-10-05"] === "Absent";
  });

  test("Attendance summary counts recorded statuses", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    markAttendance({
      staffId: "staff-test-1",
      date: "2026-10-05",
      status: "Present",
    });

    markAttendance({
      staffId: "staff-test-1",
      date: "2026-10-06",
      status: "Absent",
    });

    markAttendance({
      staffId: "staff-test-1",
      date: "2026-10-07",
      status: "Leave",
    });

    markAttendance({
      staffId: "staff-test-1",
      date: "2026-10-08",
      status: "Holiday",
    });

    const summary = getAttendanceSummary(
      "staff-test-1",
      "2026-10-01",
      "2026-10-31",
    );

    return (
      summary.presentDays === 1 &&
      summary.absentDays === 1 &&
      summary.leaveDays === 1 &&
      summary.holidayDays === 1 &&
      summary.recordedDays === 4
    );
  });

  /* =======================================================
     SALARY SERVICE TESTS
  ======================================================= */

  test("Salary service uses saved staff and attendance", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    markAttendance({
      staffId: "staff-test-1",
      date: "2026-10-05",
      status: "Absent",
    });

    const result = calculateStaffSalary("staff-test-1", "2026-10");

    return (
      result.monthlySalary === 30000 &&
      result.attendanceDeduction === 1000 &&
      result.payableSalary === 29000
    );
  });

  test("Salary service records a monthly payment", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    recordSalaryPayment({
      staffId: "staff-test-1",
      month: "2026-10",
      amount: 30000,
      paidAt: "2026-10-31",
      method: "Bank Transfer",
    });

    const payments = listSalaryPayments({
      staffId: "staff-test-1",
      month: "2026-10",
    });

    return (
      payments.length === 1 &&
      payments[0].amount === 30000 &&
      payments[0].status === "Paid"
    );
  });

  test("Salary service rejects duplicate monthly payments", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    const input = {
      staffId: "staff-test-1",
      month: "2026-10",
      amount: 30000,
      paidAt: "2026-10-31",
      method: "Bank Transfer" as const,
    };

    recordSalaryPayment(input);

    try {
      recordSalaryPayment(input);
      return false;
    } catch {
      return true;
    }
  });

  test("Salary service filters payments by month", () => {
    enableServiceTestStorage();
    resetServiceTestStorage();

    recordSalaryPayment({
      staffId: "staff-test-1",
      month: "2026-10",
      amount: 30000,
      paidAt: "2026-10-31",
      method: "Bank Transfer",
    });

    return (
      listSalaryPayments({ month: "2026-10" }).length === 1 &&
      listSalaryPayments({ month: "2026-11" }).length === 0
    );
  });

  /* =======================================================
     ACCOUNTING ENGINE TESTS
  ======================================================= */

  function createAccountingEntry(
    overrides: Partial<AccountingEntry> = {},
  ): AccountingEntry {
    return {
      id: "accounting-test-1",
      amount: 1000,
      type: "collection",
      status: "completed",
      date: "2026-10-12",
      ...overrides,
    };
  }

  test("Accounting calculates collections, expenses, and refunds", () => {
    const entries: AccountingEntry[] = [
      createAccountingEntry({
        id: "fee-1",
        amount: 10000,
        category: "student_fee",
      }),
      createAccountingEntry({
        id: "expense-1",
        amount: 2000,
        type: "expense",
        category: "business_expense",
      }),
      createAccountingEntry({
        id: "refund-1",
        amount: 1000,
        type: "refund",
        category: "refund",
      }),
    ];

    const result = calculateAccountingSummary(entries);

    return (
      result.totalCollections === 10000 &&
      result.totalExpenses === 2000 &&
      result.totalRefunds === 1000 &&
      result.netProfit === 7000 &&
      result.pendingCollections === 0
    );
  });

  test("Pending and cancelled transactions are excluded from completed totals", () => {
    const entries: AccountingEntry[] = [
      createAccountingEntry({
        id: "completed",
        amount: 5000,
      }),
      createAccountingEntry({
        id: "pending",
        amount: 2000,
        status: "pending",
      }),
      createAccountingEntry({
        id: "cancelled",
        amount: 3000,
        status: "cancelled",
      }),
    ];

    const result = calculateAccountingSummary(entries);

    return (
      result.totalCollections === 5000 &&
      result.pendingCollections === 2000 &&
      result.netProfit === 5000
    );
  });

  test("Advance receipt is counted once, not again as an allocation", () => {
    const entries: AccountingEntry[] = [
      createAccountingEntry({
        id: "advance-receipt-1",
        amount: 5000,
        category: "student_advance",
      }),
    ];

    const result = calculateMixedAccountingSummary(entries);

    return (
      result.totalCollections === 5000 &&
      result.studentAdvanceReceipts === 5000 &&
      result.netProfit === 5000
    );
  });

  test("Salary is included in total expenses exactly once", () => {
    const entries: AccountingEntry[] = [
      createAccountingEntry({
        id: "collection-1",
        amount: 20000,
        category: "student_fee",
      }),
      createAccountingEntry({
        id: "salary-1",
        amount: 5000,
        type: "expense",
        category: "salary",
      }),
    ];

    const result = calculateMixedAccountingSummary(entries);

    return (
      result.totalCollections === 20000 &&
      result.totalExpenses === 5000 &&
      result.salaryExpenses === 5000 &&
      result.businessExpenses === 0 &&
      result.netProfit === 15000
    );
  });

  test("BizBook subscription revenue is reported separately", () => {
    const entries: AccountingEntry[] = [
      createAccountingEntry({
        id: "coaching-fee-1",
        amount: 10000,
        category: "student_fee",
        coachingId: "coaching-1",
      }),
      createAccountingEntry({
        id: "subscription-1",
        amount: 500,
        category: "bizbook_subscription",
      }),
    ];

    const result = calculateMixedAccountingSummary(entries);

    return (
      result.totalCollections === 10500 &&
      result.studentFeeCollections === 10000 &&
      result.bizbookSubscriptionRevenue === 500
    );
  });

  test("Duplicate accounting transaction IDs are rejected", () => {
    const entries: AccountingEntry[] = [
      createAccountingEntry({
        id: "duplicate-1",
        amount: 1000,
      }),
      createAccountingEntry({
        id: "duplicate-1",
        amount: 2000,
      }),
    ];

    try {
      calculateAccountingSummary(entries);
      return false;
    } catch {
      return true;
    }
  });

  test("Invalid accounting category is rejected", () => {
    const invalidEntry = {
      ...createAccountingEntry({
        id: "invalid-category-1",
      }),
      category: "unknown_category",
    } as unknown as AccountingEntry;

    try {
      calculateAccountingSummary([invalidEntry]);
      return false;
    } catch {
      return true;
    }
  });

  test("Salary category cannot be used for a collection", () => {
    const invalidEntry = createAccountingEntry({
      id: "invalid-salary-1",
      type: "collection",
      category: "salary",
    });

    try {
      calculateAccountingSummary([invalidEntry]);
      return false;
    } catch {
      return true;
    }
  });

  test("Negative accounting amounts are rejected", () => {
    const entry = createAccountingEntry({
      id: "negative-amount-1",
      amount: -100,
    });

    try {
      calculateAccountingSummary([entry]);
      return false;
    } catch {
      return true;
    }
  });

  test("Cancelled refunds are excluded from refund totals", () => {
    const entries: AccountingEntry[] = [
      createAccountingEntry({
        id: "completed-refund",
        amount: 500,
        type: "refund",
        category: "refund",
      }),
      createAccountingEntry({
        id: "cancelled-refund",
        amount: 300,
        type: "refund",
        category: "refund",
        status: "cancelled",
      }),
    ];

    const result = calculateAccountingSummary(entries);

    return (
      result.totalRefunds === 500 &&
      result.netProfit === -500
    );
  });

  /* =======================================================
     PAYMENT ENGINE TESTS
  ======================================================= */

  test("Online payment starts as Pending", () => {
    const payment = createPayment({
      id: "online-pending-test",
      studentId: "student-1",
      amount: 2500,
      method: "Online",
      mode: "Online",
      createdAt: "2026-10-12T10:00:00.000Z",
    });

    return (
      payment.status === "Pending" &&
      payment.mode === "Online" &&
      !canApplyPayment(payment)
    );
  });

  test("Offline payment is recorded as Paid", () => {
    const payment = recordOfflinePayment({
      payment: {
        id: "offline-paid-test",
        studentId: "student-1",
        amount: 1500,
        method: "Cash",
        mode: "Manual",
        createdAt: "2026-10-12T10:00:00.000Z",
      },
      recordedBy: "staff-1",
      reference: "CASH-001",
    });

    return (
      payment.status === "Paid" &&
      payment.mode === "Manual" &&
      payment.providerReference === "CASH-001" &&
      canApplyPayment(payment)
    );
  });

  test("Offline payment rejects missing staff identity", () => {
    try {
      recordOfflinePayment({
        payment: {
          id: "offline-no-staff",
          studentId: "student-1",
          amount: 1000,
          method: "Cash",
          mode: "Manual",
        },
        recordedBy: "",
      });

      return false;
    } catch {
      return true;
    }
  });

  test("Online payment rejects an unverified transaction", () => {
    const pending = createPayment({
      id: "online-unverified-test",
      studentId: "student-1",
      amount: 2000,
      method: "Online",
      mode: "Online",
    });

    try {
      verifyOnlinePayment(pending, {
        paymentId: pending.id,
        providerReference: "provider-ref-1",
        verifiedAmount: 2000,
        verified: false,
      });

      return false;
    } catch {
      return true;
    }
  });

  test("Online verification rejects an amount mismatch", () => {
    const pending = createPayment({
      id: "online-amount-mismatch",
      studentId: "student-1",
      amount: 2000,
      method: "Online",
      mode: "Online",
    });

    try {
      verifyOnlinePayment(pending, {
        paymentId: pending.id,
        providerReference: "provider-ref-2",
        verifiedAmount: 1500,
        verified: true,
      });

      return false;
    } catch {
      return true;
    }
  });

  test("Verified online payment becomes eligible", () => {
    const pending = createPayment({
      id: "online-verified-test",
      studentId: "student-1",
      amount: 2000,
      method: "Online",
      mode: "Online",
    });

    const paid = verifyOnlinePayment(pending, {
      paymentId: pending.id,
      providerReference: "provider-ref-3",
      verifiedAmount: 2000,
      verified: true,
      verifiedAt: "2026-10-12T10:30:00.000Z",
    });

    return (
      paid.status === "Paid" &&
      paid.verifiedAt === "2026-10-12T10:30:00.000Z" &&
      canApplyPayment(paid)
    );
  });

  test("Payment amount converts to paise", () => {
    const payment = createPayment({
      id: "payment-paise-test",
      studentId: "student-1",
      amount: 123.45,
      method: "Online",
      mode: "Online",
    });

    return getPaymentAmountPaise(payment) === 12345;
  });

  /* =======================================================
     RECEIPT ENGINE TESTS
  ======================================================= */

  test("Receipt is generated for a recorded offline payment", () => {
    const student: Student = {
      id: "receipt-student-1",
      name: "Test Student",
      course: "Test Course",
      totalFee: 5000,
      installments: [],
    };

    const payment = recordOfflinePayment({
      payment: {
        id: "receipt-payment-1",
        studentId: student.id,
        amount: 1000,
        method: "Cash",
        mode: "Manual",
        createdAt: "2026-10-12T10:00:00.000Z",
      },
      recordedBy: "staff-1",
    });

    const receipts: AdvancePayment[] = [
      {
        id: payment.id,
        studentId: student.id,
        studentName: student.name,
        course: student.course,
        amount: payment.amount,
        paymentDate: "2026-10-12",
        method: payment.method,
        createdAt: payment.createdAt,
        // The receipt engine models AdvancePayment rows as receipts.
        // Mark the fee receipt fully applied so it is not shown as
        // unallocated advance in this engine-level test.
        appliedAmount: payment.amount,
        appliedTo: [],
      },
    ];

    const receipt = createPaymentReceipt(
      payment,
      student,
      receipts,
      "2026-10-12",
    );

    return (
      receipt.paymentId === payment.id &&
      receipt.studentId === student.id &&
      receipt.paymentStatus === "Paid" &&
      receipt.amount === 1000 &&
      receipt.totalReceived === 1000 &&
      receipt.advanceAvailable === 0 &&
      receipt.receiptNumber === `BB-${payment.id}`
    );
  });

  test("Receipt generation rejects a pending online payment", () => {
    const student: Student = {
      id: "pending-receipt-student",
      name: "Pending Student",
      totalFee: 3000,
    };

    const pending = createPayment({
      id: "pending-receipt-payment",
      studentId: student.id,
      amount: 1000,
      method: "Online",
      mode: "Online",
    });

    try {
      createPaymentReceipt(
        pending,
        student,
        [],
        "2026-10-12",
      );

      return false;
    } catch {
      return true;
    }
  });

  test("Receipt generation rejects a different student", () => {
    const payment = recordOfflinePayment({
      payment: {
        id: "wrong-student-payment",
        studentId: "student-A",
        amount: 1000,
        method: "UPI",
        mode: "Manual",
      },
      recordedBy: "staff-1",
    });

    const wrongStudent: Student = {
      id: "student-B",
      name: "Different Student",
      totalFee: 1000,
    };

    try {
      createPaymentReceipt(
        payment,
        wrongStudent,
        [],
        "2026-10-12",
      );

      return false;
    } catch {
      return true;
    }
  });

  /* =======================================================
     PAYMENT SERVICE INTEGRATION TESTS
  ======================================================= */

  test("Payment service stores ordinary fee receipts separately from advances", () => {
    resetPaymentServiceTestStorage();

    const result = recordOfflinePaymentService({
      payment: {
        id: "service-fee-payment-1",
        studentId: "payment-service-student",
        amount: 1500,
        method: "UPI",
        createdAt: "2026-10-13T09:00:00.000Z",
      },
      recordedBy: "staff-test-1",
      reference: "UPI-TEST-1",
    });

    const feeReceipts = readFeeReceipts();
    const advanceReceipts = readAdvancePayments();
    const history = readPaymentHistory();

    return (
      result.payment.status === "Paid" &&
      result.receiptRecord.paymentRecordId === result.payment.id &&
      feeReceipts.length === 1 &&
      feeReceipts[0]?.id === result.payment.id &&
      feeReceipts[0]?.course === "Test Course" &&
      advanceReceipts.length === 0 &&
      history.length === 1 &&
      history[0]?.id === result.payment.id &&
      readPaymentRecords().length === 1 &&
      result.receipt.advanceAvailable === 0
    );
  });

  test("Ordinary fee payment does not change an existing advance balance", () => {
    resetPaymentServiceTestStorage();

    const existingAdvance: AdvancePayment = {
      id: "service-existing-advance-1",
      studentId: "payment-service-student",
      studentName: "Payment Service Student",
      course: "Test Course",
      amount: 2000,
      paymentDate: "2026-10-12",
      method: "Cash",
      createdAt: "2026-10-12T09:00:00.000Z",
      appliedAmount: 500,
      appliedTo: [],
    };

    mockStorage.setItem(
      BIZBOOK_STORAGE_KEYS.advancePayments,
      JSON.stringify([existingAdvance]),
    );

    const result = recordOfflinePaymentService({
      payment: {
        id: "service-fee-with-advance-1",
        studentId: "payment-service-student",
        amount: 1000,
        method: "Cash",
        createdAt: "2026-10-13T10:00:00.000Z",
      },
      recordedBy: "staff-test-1",
    });

    const advancesAfterPayment = readAdvancePayments();
    const existingAdvanceAfterPayment = advancesAfterPayment[0];

    return (
      advancesAfterPayment.length === 1 &&
      existingAdvanceAfterPayment?.id === existingAdvance.id &&
      existingAdvanceAfterPayment !== undefined &&
      getReceiptAvailableAdvance(existingAdvanceAfterPayment) === 1500 &&
      readFeeReceipts().length === 1 &&
      result.receipt.advanceAvailable === 1500
    );
  });

  test("Payment service rejects duplicate payments without duplicate receipts or history", () => {
    resetPaymentServiceTestStorage();

    const input = {
      payment: {
        id: "service-duplicate-payment-1",
        studentId: "payment-service-student",
        amount: 1200,
        method: "UPI" as const,
        createdAt: "2026-10-13T11:00:00.000Z",
      },
      recordedBy: "staff-test-1",
    };

    recordOfflinePaymentService(input);

    let rejected = false;

    try {
      recordOfflinePaymentService(input);
    } catch {
      rejected = true;
    }

    return (
      rejected &&
      readPaymentRecords().length === 1 &&
      readFeeReceipts().length === 1 &&
      readPaymentHistory().length === 1
    );
  });

  test("Pending online payment does not create a receipt until verified", () => {
    resetPaymentServiceTestStorage();

    const pending = createOnlinePayment({
      payment: {
        id: "service-online-payment-1",
        studentId: "payment-service-student",
        amount: 2500,
        createdAt: "2026-10-13T12:00:00.000Z",
      },
    });

    if (
      pending.status !== "Pending" ||
      readFeeReceipts().length !== 0 ||
      readPaymentHistory().length !== 0
    ) {
      return false;
    }

    const result = verifyOnlinePaymentService({
      paymentId: pending.id,
      providerReference: "provider-test-1",
      verifiedAmount: 2500,
      verified: true,
      verifiedAt: "2026-10-13T12:01:00.000Z",
      trustedVerification: true,
    });

    return (
      result.payment.status === "Paid" &&
      readFeeReceipts().length === 1 &&
      readPaymentHistory().length === 1 &&
      readPaymentRecords().length === 1 &&
      readAdvancePayments().length === 0
    );
  });

  test("Payment service receipt lookup finds a fee receipt", () => {
    resetPaymentServiceTestStorage();

    const result = recordOfflinePaymentService({
      payment: {
        id: "service-receipt-lookup-1",
        studentId: "payment-service-student",
        amount: 900,
        method: "Card",
        createdAt: "2026-10-13T12:30:00.000Z",
      },
      recordedBy: "staff-test-1",
    });

    const receipt = getPaymentReceipt(result.payment.id);

    return (
      receipt.paymentId === result.payment.id &&
      receipt.studentId === "payment-service-student" &&
      receipt.paymentStatus === "Paid" &&
      receipt.amount === 900 &&
      receipt.advanceAvailable === 0
    );
  });

  /* =======================================================
     RETURN RESULTS
  ======================================================= */

  return results;
}

/* =========================================================
   TEST REPORT
========================================================= */

export function runAndPrintBizBookTests(): boolean {
  const results = runBizBookTestCases();

  console.log("\n========== BIZBOOK BRAIN TESTS ==========\n");

  for (const result of results) {
    console.log(
      `${result.passed ? "PASS" : "FAIL"}: ${result.name}`,
    );

    if (!result.passed && result.error) {
      console.error(`  Reason: ${result.error}`);
    }
  }

  const passed = results.filter(
    (result) => result.passed,
  ).length;

  const failed = results.length - passed;

  console.log("\n=========================================");
  console.log(`Total:  ${results.length}`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log("=========================================\n");

  return failed === 0;
}

/* =========================================================
   DIRECT EXECUTION
========================================================= */

const isDirectExecution = process.argv[1]
  ?.replace(/\\/g, "/")
  .endsWith("/lib/bizbook-brain/test-cases.ts");

if (isDirectExecution) {
  const passed = runAndPrintBizBookTests();

  if (!passed) {
    process.exitCode = 1;
  }
}

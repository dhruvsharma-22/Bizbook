"use client";

import { useEffect, useState } from "react";

export function useBizBookRefresh<T>(
  readData: () => T,
  events: string[]
): T | null {
  const [data, setData] = useState<T | null>(null);

  useEffect(() => {
    const refresh = () => {
      try {
        setData(readData());
      } catch (error) {
        console.error("BizBook data refresh failed:", error);
      }
    };

    refresh();

    events.forEach((eventName) => {
      window.addEventListener(eventName, refresh);
    });

    // Refresh when another browser tab changes localStorage.
    const onStorage = () => refresh();
    window.addEventListener("storage", onStorage);

    return () => {
      events.forEach((eventName) => {
        window.removeEventListener(eventName, refresh);
      });

      window.removeEventListener("storage", onStorage);
    };
  }, [readData, events]);

  return data;
}